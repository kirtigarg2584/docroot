<?php

namespace Drupal\april_11\Form;

use Drupal\Core\Database\Driver\mysql\Connection;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\AlertCommand;
use Drupal\Core\Ajax;
        
class April_11 extends FormBase{
    
  //  private $vertical;
    private $city = [
        0 => [
            'New Delhi' => 'New Delhi',
            'Noida' => 'Noida',
            'Haryana' => 'Haryana',
        ],
        1 =>[
            'London' => 'London',
            'Paris' => 'Paris',
            'Amsterdam' => 'Amsterdam',
        ],        
    ];
    
    protected $con;
    public function __construct(Connection $conn) {
       $this->con = $conn; 
    }    
    
    public static function create(ContainerInterface $container) {
        return new static (
          $container->get('database')
        );
    }
    
    public function buildForm(array $form, FormStateInterface $form_state){
        
     
      $form['full_name']= array(
        '#type' => 'textfield',
        '#placeholder' => 'Your username',
        '#title' => $this->t('Username'),
        '#ajax' => [
            'callback' => '::validateUser',
            'wrapper' => 'user_wrapper',
            'event' => 'change',
            'method' => 'replace',
        ]
          
      );
      
      $form['user-wrapper']= [
          '#type' => 'container',
          '#attributes' => [ 'id' => 'user_wrapper'],
      ];
      
      $form['gender'] = array(
          '#type' => 'radios',
          '#title' => $this->t('Vertical'),
         
         '#id' => 'gender-wrapper',
          '#options' => [
              'Drupal' => 'Drupal',
              'JVM' => 'JVM',
              'MEAN' => 'MEAN',
              'FEEN' => 'FEEN',
           ],
          '#ajax' => [
              'callback' => '::validateVertical',
             // 'wrapper' => 'vertical_wrapper',
          ]
        );
     
//      $form['vertical-wrapper']=[
//          '#type' => 'container',
//        //  '#value' => $vertical,
//          '#attributes' => [ 'id' => 'vertical_wrapper'],
//      ];
        
        $form['number']= array(
          '#type' => 'textfield',
          '#title' => $this->t('Contact Number'),
        //  '#default_value' => $conf->get('number') ? $conf->get('number') : '',
          '#placeholder' => $this->t('Your contact number'),
        );
        
        $form['email_id']= array(
          '#type' => 'textfield',
          '#title' => $this->t('Email Id'),
         // '#default_value' => $conf->get('email_id') ? $conf->get('email_id') : '',
          '#placeholder' => $this->t('abc@xyz.pqr'),
        );
        
        $form['add']= array(
          '#type' => 'textarea',
          '#title' => $this->t('Address'),
         // '#default_value' => $conf->get('add') ? $conf->get('add') : '',
          '#placeholder' => $this->t('Your address'),
        );
        
        $form['countary'] = array(
            '#type' => 'select',
            '#title' => 'Country',
            '#empty_option' => $this->t('-select'),
            '#options' => ['India','Europe'],
            '#ajax' => [
                'callback' => '::displayCities',
                'wrapper' => 'countary_wrapper',
                'progress' => array(
                'type' => 'throbber',
                'message' => NULL,
             ),
            ],
        );
        
        $form['countary-wrapper']=[
            '#type' => 'container',
            '#attributes' => ['id' => 'countary_wrapper']        
        ];
        
        $form['password'] = array(
          '#type'  => 'password',
          '#title' => 'Create Password',
        );
        
        $form['re-password'] = array(
          '#type'  => 'password',
          '#title' => 'Confirmsss Password',
        );
        
        $form['agree']= array(
          '#type' => 'checkbox',
          '#title' => $this->t('I agree to all the terms and condition mentioned'),
          '#ajax' => [
              'callback' => '::validate_Agree',
              'wrapper' => 'actions_ajax',
               'event' => 'change'
          ],
        );
        
        $form['actions'] = [
            '#type' => 'submit',
            '#value' => $this->t('Save'),
            '#button_type' => 'primary',
            '#attributes' => ['disabled' => 'true','id' => 'actions_ajax'] 
        ];

      return $form;
        
    }
    
    public function validateUser(array &$form, FormStateInterface $form_state) {
        if(!preg_match('/^[a-zA-Z0-9._@]+$/', $form_state->getValue('full_name'))){
          $error = 'User name can not any special character other than (.),(_),(@)';
        }
        else{
            $query = $this->con->select('services_2','kirti');
            $query->fields('kirti',['full_name']);
            $query->condition('full_name', $form_state->getValue('full_name') , '=');
            $result = $query->execute()->fetchAll();
            if(count($result)){
                    $error = 'UserName already exists';
            }
        }
        
        $form['user-wrapper']['user-error'] = [
              '#type' => 'label',
              '#title' => $error,
          ];
   
     return $form['user-wrapper'];
    }
    
    public function displayCities(array &$form, FormStateInterface $form_state) {
        
        $form['countary-wrapper']['city_ajax']= [
            '#type'=> 'select',
            '#title'=> 'City',
            '#empty_option' => $this->t('-select'),
            '#options' => $this->city[$form_state->getValue('countary')],
        ];
        
        return $form['countary-wrapper'];
    }
    
    public function validate_Agree(array &$form, FormStateInterface $form_state) {
       // echo ($form_state->getValue('agree'));die;
        if($form_state->getValue('agree')){
           unset($form['actions']['#attributes']['disabled']); 
        }
        else{
            $form['actions']['#attributes']['disabled'] = 'false';
        }        
        return $form['actions'];
    }

    public function validateVertical(array &$form, FormStateInterface $form_state){
 
        $response = new AjaxResponse();
        $response->addCommand(new Ajax\ReplaceCommand('#gender-wrapper',$form_state->getValue('gender')));
        //$response->addCommand(new Ajax\('#gender-wrapper')));
        return $response;
        }

    public function getFormId(){
        return 'april_11_form';
    }

    public function submitForm(array &$form, FormStateInterface $form_state) {
        //   kint($form_state->getValue('op')->__toString());die;
        
        $this->con->insert('services_2')->fields([
          'full_name'=> $form_state->getValue('full_name'), 
            'gender'=>  $form_state->getValue('gender')? :'Female',
            'address'=> $form_state->getValue('add'),
            'city'=> $form_state->getValue('city'),
            'number'=> $form_state->getValue('number'),
            'email_id'=> $form_state->getValue('email_id')  
        ])->execute();
    }

}

